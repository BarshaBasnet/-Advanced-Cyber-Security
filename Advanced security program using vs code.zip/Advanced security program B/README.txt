	Development tools: Python and Django
			
		Steps to setup and run app:

0. Open vscode terminal
1. Activate virtualenv which is sys folder -> sys/Scripts/activate
				OR 
   Create your own virtualenv and activate it -> virtualenv envname

2. Then, cd securityProject
3. pip install -r requirements.txt
4. create superuser -> django-admin createsuperuser 
5. python manage.py makemigrations
6. python manage.py migrate
7. python manage.py runserver



