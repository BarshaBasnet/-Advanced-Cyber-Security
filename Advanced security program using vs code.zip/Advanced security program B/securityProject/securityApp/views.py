from django.shortcuts import render, redirect 
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .gocaptcha import CaptchaForm
# Create your views here.
from .forms import  CreateUserForm
from django.contrib.auth.models import User
from .decorators import admin_only

def Registration(request):
	form = CreateUserForm()
	if request.method == 'POST':
		form = CreateUserForm(request.POST)
		captchaform = CaptchaForm(request.POST)
		email = request.POST.get('email')

		if User.objects.filter(email = email).first():
			messages.error(request, "Email already exists!")

		elif form.is_valid() and captchaform.is_valid():
			form.save()
			user = form.cleaned_data.get('username')
			messages.success(request, 'Account has been created for ' + user)
			email = request.POST.get('email')
			return redirect('LoginPg')

		else:
			messages.error(request, "Invalid Captcha!")

	context = {
		'form': form,
		"captcha": CaptchaForm,
		}

	return render(request, 'accounts/registrationpg.html', context)
	
def LoginPg(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(request, username=username, password=password)

		if user is not None:
			login(request, user)
			return redirect('dashboard')

		else:
			messages.info(request, 'Username OR Password is incorrect')

	context = {}
	return render(request, 'accounts/loginpg.html', context)

def SignOut(request):
	logout(request)
	return redirect('LoginPg')

@login_required(login_url='login')
def dashboard0(request):
	return render(request, 'accounts/dashboard0.html')

@login_required(login_url='login')
@admin_only
def dashboard(request):
	return render(request, 'accounts/dashboard.html')

def success(request):
	return render(request, 'accounts/success.html')

def send_token(request):
	return render(request, 'accounts/send_token.html')

def error_page(request):
    return  render(request , 'error.html')




