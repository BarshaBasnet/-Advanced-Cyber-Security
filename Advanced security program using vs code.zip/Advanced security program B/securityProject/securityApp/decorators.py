from django.shortcuts import redirect
from django.shortcuts import render


def admin_only(view_func):
	def wrapper_function(request, *args, **kwargs):
		group = None
		if request.user.groups.exists():
			group = request.user.groups.all()[0].name

		if group == 'general' or group == None:
			return redirect('dashboard0')

		if group == 'admin':
			return render(request, 'accounts/dashboard.html')
			# return view_func(request, *args, **kwargs)

	return wrapper_function


	