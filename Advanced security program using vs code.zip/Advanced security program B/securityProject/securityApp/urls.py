from django.urls import path
from . import views
from django.contrib import admin
from django.contrib.auth import views as auth_views


urlpatterns = [
	path('', views.Registration, name="Registration"),
	path('login/', views.LoginPg, name="LoginPg"),  
	path('signout/', views.SignOut, name="signout"),
    path('token/', views.send_token, name="send_token"),
    path('success/', views.success, name="success"),
    path('error' , views.error_page , name="error"),
    path('dashboard/', views.dashboard, name="dashboard"),
    path('dashboard0/', views.dashboard0, name="dashboard0"),

     path('reset_password/',
     auth_views.PasswordResetView.as_view(template_name="accounts/password_reset.html"),
     name="reset_password"),

    path('reset_password_sent/', 
auth_views.PasswordResetDoneView.as_view(template_name="accounts/password_reset_sent.html"), 
        name="password_reset_done"),

    path('reset/<uidb64>/<token>/',
auth_views.PasswordResetConfirmView.as_view(template_name="accounts/password_reset_form.html"), 
     name="password_reset_confirm"),

    path('reset_password_complete/', 
auth_views.PasswordResetCompleteView.as_view(template_name="accounts/password_reset_done.html"), 
        name="password_reset_complete"),
]






